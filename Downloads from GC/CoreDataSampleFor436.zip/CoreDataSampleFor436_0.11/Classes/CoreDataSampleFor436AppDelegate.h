//
//  CoreDataSampleFor436AppDelegate.h
//  CoreDataSampleFor436
//
//  Created by Eric Peter on 3/20/10.
//  Copyright __MyCompanyName__ 2010. All rights reserved.
//

@interface CoreDataSampleFor436AppDelegate : NSObject <UIApplicationDelegate> {

    UIWindow *window;
	UINavigationController *_navigationController;
}

@property (nonatomic, retain) UINavigationController *navigationController;


@property (nonatomic, retain) IBOutlet UIWindow *window;


@end

