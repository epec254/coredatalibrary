// 
//  ManufacturingProcess.m
//  CoreDataSampleFor436
//
//  Created by Eric Peter on 3/20/10.
//  Copyright 2010 __MyCompanyName__. All rights reserved.
//

#import "ManufacturingProcess.h"

#import "WidgetToManufacturingProcess.h"

@implementation ManufacturingProcess 

@dynamic name;
@dynamic type;
@dynamic widgetManufacturingProcesses;

@end
