// 
//  WidgetManufacturingProcess.m
//  CoreDataSampleFor436
//
//  Created by Eric Peter on 3/20/10.
//  Copyright 2010 __MyCompanyName__. All rights reserved.
//

#import "WidgetToManufacturingProcess.h"

#import "ManufacturingProcess.h"
#import "Widget.h"

@implementation WidgetToManufacturingProcess 

@dynamic order;
@dynamic widgets;
@dynamic manufacturingProcess;

@end
