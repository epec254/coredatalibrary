// 
//  ManufacturingProcessType.m
//  CoreDataSampleFor436
//
//  Created by Eric Peter on 3/20/10.
//  Copyright 2010 __MyCompanyName__. All rights reserved.
//

#import "ManufacturingProcessType.h"

#import "ManufacturingProcess.h"

@implementation ManufacturingProcessType 

@dynamic name;
@dynamic manufacturingProcesses;

@end
