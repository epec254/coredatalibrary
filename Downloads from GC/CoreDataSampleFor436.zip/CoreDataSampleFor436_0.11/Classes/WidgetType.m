// 
//  WidgetType.m
//  CoreDataSampleFor436
//
//  Created by Eric Peter on 3/20/10.
//  Copyright 2010 __MyCompanyName__. All rights reserved.
//

#import "WidgetType.h"

#import "Widget.h"

@implementation WidgetType 

@dynamic name;
@dynamic details;
@dynamic widgets;

@end
