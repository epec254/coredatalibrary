//
//  DemoViewController.h
//  CoreDataSampleFor436
//
//  Created by Eric Peter on 4/6/10.
//  Copyright 2010 __MyCompanyName__. All rights reserved.
//



@interface DemoViewController : UITableViewController {

}

@end
