// 
//  EventType.m
//  GettingStarted
//
//  Created by Eric Peter on 4/12/10.
//  Copyright 2010 __MyCompanyName__. All rights reserved.
//

#import "EventType.h"

#import "Event.h"

@implementation EventType 

@dynamic name;
@dynamic events;

@end
