// 
//  Event.m
//  GettingStarted
//
//  Created by Eric Peter on 4/12/10.
//  Copyright 2010 __MyCompanyName__. All rights reserved.
//

#import "Event.h"

#import "EventType.h"

@implementation Event 

@dynamic timeStamp;
@dynamic detail;
@dynamic name;
@dynamic publicEvent;
@dynamic type;

@end
