// 
//  Event.m
//  ___PROJECTNAME___
//
//  Created by Eric Peter on 4/6/10.
//  Copyright 2010 __MyCompanyName__. All rights reserved.
//

#import "Event.h"


@implementation Event 

@dynamic name;
@dynamic timeStamp;

@end
