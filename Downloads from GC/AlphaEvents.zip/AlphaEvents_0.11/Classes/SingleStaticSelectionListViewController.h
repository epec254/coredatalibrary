//
//  SingleStaticSelectionListViewController.h
//  BEPersonalTrainingManager
//
//  Created by Eric Peter on 2/15/10.
//  Copyright 2010 __MyCompanyName__. All rights reserved.
//
//
//#import "CDLToOneRelationshipEditController.h"
//
//@interface SingleStaticSelectionListViewController : CDLToOneRelationshipEditController {
//
//}
//- (id) initForEditingObject:(NSManagedObject *)managedObject listOfChoices:(NSArray *)choicesArray;
//@end
