// 
//  Event.m
//  ToManyEvents
//
//  Created by Eric Peter on 4/7/10.
//  Copyright 2010 __MyCompanyName__. All rights reserved.
//

#import "Event.h"

#import "EventToVIP.h"

@implementation Event 

@dynamic name;
@dynamic timeStamp;
@dynamic vips;

@end
