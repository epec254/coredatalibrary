//
//  CDLMultiLineTableRowController.m
//  CoreDataLibrary
//
//  
//  Copyright 2010 Eric Peter. 
//  Released under the GPL v3 License
//
//  code.google.com/p/coredatalibrary


#import "CDLTableRowController.h"


@interface CDLMultiLineTableRowController : CDLTableRowController {

}

@end
