// 
//  EventToVIP.m
//  ToManyEvents
//
//  Created by Eric Peter on 4/7/10.
//  Copyright 2010 __MyCompanyName__. All rights reserved.
//

#import "EventToVIP.h"

#import "Event.h"
#import "VIP.h"

@implementation EventToVIP 

@dynamic order;
@dynamic vip;
@dynamic event;

@end
