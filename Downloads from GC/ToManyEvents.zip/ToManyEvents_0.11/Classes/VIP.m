// 
//  VIP.m
//  ToManyEvents
//
//  Created by Eric Peter on 4/7/10.
//  Copyright 2010 __MyCompanyName__. All rights reserved.
//

#import "VIP.h"

#import "EventToVIP.h"

@implementation VIP 

@dynamic name;
@dynamic eventVIPs;

@end
